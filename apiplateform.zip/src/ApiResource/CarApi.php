<?php
namespace App\ApiResource;

use App\Entity\Car;
// use ApiPlatform\Doctrine\Orm\State\CollectionProvider;
use ApiPlatform\Metadata\ApiFilter;
use ApiPlatform\Metadata\ApiResource;
use ApiPlatform\Doctrine\Orm\State\Options;
use ApiPlatform\Doctrine\Orm\Filter\SearchFilter;
use ApiPlatform\Doctrine\Orm\State\CollectionProvider;

#[ApiResource(
    shortName: 'Car',
    provider: CollectionProvider::class,
    stateOptions: new Options(entityClass: Car::class),
)]

#[ApiFilter(SearchFilter::class, properties: [
    'year' => 'partial',
])]

class CarApi
{
    public ?int $id = null;
    public ?int $year = null;

}