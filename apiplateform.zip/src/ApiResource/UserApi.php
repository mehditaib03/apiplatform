<?php
namespace App\ApiResource;

use App\Entity\User;
// use ApiPlatform\Doctrine\Orm\State\CollectionProvider;
use ApiPlatform\Metadata\ApiResource;
use App\State\EntityToDtoStateProvider;
use ApiPlatform\Doctrine\Orm\State\Options;


#[ApiResource(
    shortName: 'User',
    // provider: CollectionProvider::class,
    paginationItemsPerPage: 5,
    provider: EntityToDtoStateProvider::class,
    stateOptions: new Options(entityClass: User::class),
)]

class UserApi
{
    public ?int $id = null;
    public ?string $email = null;
    public ?string $fullname = null;
    //  /**
    //  * @var Collection<int, Car>
    //  */
    // public ?array $cars = null;
    
     /**
     * @var CarApi[]
     */
    public ?array $cars = null;
    
}